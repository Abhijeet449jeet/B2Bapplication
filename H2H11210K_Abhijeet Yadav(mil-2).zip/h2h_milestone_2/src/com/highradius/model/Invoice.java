package com.highradius.model;

public class Invoice {
	private int Sl_no;
    private int CUSTOMER_ORDER_ID;
    private int SALES_ORG;
    private String DISTRIBUION_CHANNEL;
    private String DIVISION;
    private double RELEASED_CREDIT_VALUE;
    private String PURCHASE_ORDER_TYPE;
    private int COMPANY_CODE;
    private String ORDER_CREATION_DATE;
    private String ORDER_CREATION_TIME;
    private String CREDIT_CONTROL_AREA;
    private int SOLD_TO_PARTY;
    private double ORDER_AMOUNT;
    private String REQUESTED_DELIVERY_DATE;
    private String ORDER_CURRENCY;
    private String CREDIT_STATUS;
    private int CUSTOMER_NUMBER;
    private double AMOUNT_IN_USD;
    private long UNIQUE_CUST_ID;
	public Invoice(int sl_no, int cUSTOMER_ORDER_ID, int sALES_ORG, String dISTRIBUION_CHANNEL, String dIVISION,
			double rELEASED_CREDIT_VALUE, String pURCHASE_ORDER_TYPE, int cOMPANY_CODE, String oRDER_CREATION_DATE,
			String oRDER_CREATION_TIME, String cREDIT_CONTROL_AREA, int sOLD_TO_PARTY, double oRDER_AMOUNT,
			String rEQUESTED_DELIVERY_DATE, String oRDER_CURRENCY, String cREDIT_STATUS, int cUSTOMER_NUMBER,
			double aMOUNT_IN_USD, long uNIQUE_CUST_ID) {
		super();
		Sl_no = sl_no;
		CUSTOMER_ORDER_ID = cUSTOMER_ORDER_ID;
		SALES_ORG = sALES_ORG;
		DISTRIBUION_CHANNEL = dISTRIBUION_CHANNEL;
		DIVISION = dIVISION;
		RELEASED_CREDIT_VALUE = rELEASED_CREDIT_VALUE;
		PURCHASE_ORDER_TYPE = pURCHASE_ORDER_TYPE;
		COMPANY_CODE = cOMPANY_CODE;
		ORDER_CREATION_DATE = oRDER_CREATION_DATE;
		ORDER_CREATION_TIME = oRDER_CREATION_TIME;
		CREDIT_CONTROL_AREA = cREDIT_CONTROL_AREA;
		SOLD_TO_PARTY = sOLD_TO_PARTY;
		ORDER_AMOUNT = oRDER_AMOUNT;
		REQUESTED_DELIVERY_DATE = rEQUESTED_DELIVERY_DATE;
		ORDER_CURRENCY = oRDER_CURRENCY;
		CREDIT_STATUS = cREDIT_STATUS;
		CUSTOMER_NUMBER = cUSTOMER_NUMBER;
		AMOUNT_IN_USD = aMOUNT_IN_USD;
		UNIQUE_CUST_ID = uNIQUE_CUST_ID;
	}
	/**
	 * @return the sl_no
	 */
	public int getSl_no() {
		return Sl_no;
	}
	/**
	 * @param sl_no the sl_no to set
	 */
	public void setSl_no(int sl_no) {
		Sl_no = sl_no;
	}
	/**
	 * @return the cUSTOMER_ORDER_ID
	 */
	public int getCUSTOMER_ORDER_ID() {
		return CUSTOMER_ORDER_ID;
	}
	/**
	 * @param cUSTOMER_ORDER_ID the cUSTOMER_ORDER_ID to set
	 */
	public void setCUSTOMER_ORDER_ID(int cUSTOMER_ORDER_ID) {
		CUSTOMER_ORDER_ID = cUSTOMER_ORDER_ID;
	}
	/**
	 * @return the sALES_ORG
	 */
	public int getSALES_ORG() {
		return SALES_ORG;
	}
	/**
	 * @param sALES_ORG the sALES_ORG to set
	 */
	public void setSALES_ORG(int sALES_ORG) {
		SALES_ORG = sALES_ORG;
	}
	/**
	 * @return the dISTRIBUION_CHANNEL
	 */
	public String getDISTRIBUION_CHANNEL() {
		return DISTRIBUION_CHANNEL;
	}
	/**
	 * @param dISTRIBUION_CHANNEL the dISTRIBUION_CHANNEL to set
	 */
	public void setDISTRIBUION_CHANNEL(String dISTRIBUION_CHANNEL) {
		DISTRIBUION_CHANNEL = dISTRIBUION_CHANNEL;
	}
	/**
	 * @return the dIVISION
	 */
	public String getDIVISION() {
		return DIVISION;
	}
	/**
	 * @param dIVISION the dIVISION to set
	 */
	public void setDIVISION(String dIVISION) {
		DIVISION = dIVISION;
	}
	/**
	 * @return the rELEASED_CREDIT_VALUE
	 */
	public double getRELEASED_CREDIT_VALUE() {
		return RELEASED_CREDIT_VALUE;
	}
	/**
	 * @param rELEASED_CREDIT_VALUE the rELEASED_CREDIT_VALUE to set
	 */
	public void setRELEASED_CREDIT_VALUE(double rELEASED_CREDIT_VALUE) {
		RELEASED_CREDIT_VALUE = rELEASED_CREDIT_VALUE;
	}
	/**
	 * @return the pURCHASE_ORDER_TYPE
	 */
	public String getPURCHASE_ORDER_TYPE() {
		return PURCHASE_ORDER_TYPE;
	}
	/**
	 * @param pURCHASE_ORDER_TYPE the pURCHASE_ORDER_TYPE to set
	 */
	public void setPURCHASE_ORDER_TYPE(String pURCHASE_ORDER_TYPE) {
		PURCHASE_ORDER_TYPE = pURCHASE_ORDER_TYPE;
	}
	/**
	 * @return the cOMPANY_CODE
	 */
	public int getCOMPANY_CODE() {
		return COMPANY_CODE;
	}
	/**
	 * @param cOMPANY_CODE the cOMPANY_CODE to set
	 */
	public void setCOMPANY_CODE(int cOMPANY_CODE) {
		COMPANY_CODE = cOMPANY_CODE;
	}
	/**
	 * @return the oRDER_CREATION_DATE
	 */
	public String getORDER_CREATION_DATE() {
		return ORDER_CREATION_DATE;
	}
	/**
	 * @param oRDER_CREATION_DATE the oRDER_CREATION_DATE to set
	 */
	public void setORDER_CREATION_DATE(String oRDER_CREATION_DATE) {
		ORDER_CREATION_DATE = oRDER_CREATION_DATE;
	}
	/**
	 * @return the oRDER_CREATION_TIME
	 */
	public String getORDER_CREATION_TIME() {
		return ORDER_CREATION_TIME;
	}
	/**
	 * @param oRDER_CREATION_TIME the oRDER_CREATION_TIME to set
	 */
	public void setORDER_CREATION_TIME(String oRDER_CREATION_TIME) {
		ORDER_CREATION_TIME = oRDER_CREATION_TIME;
	}
	/**
	 * @return the cREDIT_CONTROL_AREA
	 */
	public String getCREDIT_CONTROL_AREA() {
		return CREDIT_CONTROL_AREA;
	}
	/**
	 * @param cREDIT_CONTROL_AREA the cREDIT_CONTROL_AREA to set
	 */
	public void setCREDIT_CONTROL_AREA(String cREDIT_CONTROL_AREA) {
		CREDIT_CONTROL_AREA = cREDIT_CONTROL_AREA;
	}
	/**
	 * @return the sOLD_TO_PARTY
	 */
	public int getSOLD_TO_PARTY() {
		return SOLD_TO_PARTY;
	}
	/**
	 * @param sOLD_TO_PARTY the sOLD_TO_PARTY to set
	 */
	public void setSOLD_TO_PARTY(int sOLD_TO_PARTY) {
		SOLD_TO_PARTY = sOLD_TO_PARTY;
	}
	/**
	 * @return the oRDER_AMOUNT
	 */
	public double getORDER_AMOUNT() {
		return ORDER_AMOUNT;
	}
	/**
	 * @param oRDER_AMOUNT the oRDER_AMOUNT to set
	 */
	public void setORDER_AMOUNT(double oRDER_AMOUNT) {
		ORDER_AMOUNT = oRDER_AMOUNT;
	}
	/**
	 * @return the rEQUESTED_DELIVERY_DATE
	 */
	public String getREQUESTED_DELIVERY_DATE() {
		return REQUESTED_DELIVERY_DATE;
	}
	/**
	 * @param rEQUESTED_DELIVERY_DATE the rEQUESTED_DELIVERY_DATE to set
	 */
	public void setREQUESTED_DELIVERY_DATE(String rEQUESTED_DELIVERY_DATE) {
		REQUESTED_DELIVERY_DATE = rEQUESTED_DELIVERY_DATE;
	}
	/**
	 * @return the oRDER_CURRENCY
	 */
	public String getORDER_CURRENCY() {
		return ORDER_CURRENCY;
	}
	/**
	 * @param oRDER_CURRENCY the oRDER_CURRENCY to set
	 */
	public void setORDER_CURRENCY(String oRDER_CURRENCY) {
		ORDER_CURRENCY = oRDER_CURRENCY;
	}
	/**
	 * @return the cREDIT_STATUS
	 */
	public String getCREDIT_STATUS() {
		return CREDIT_STATUS;
	}
	/**
	 * @param cREDIT_STATUS the cREDIT_STATUS to set
	 */
	public void setCREDIT_STATUS(String cREDIT_STATUS) {
		CREDIT_STATUS = cREDIT_STATUS;
	}
	/**
	 * @return the cUSTOMER_NUMBER
	 */
	public int getCUSTOMER_NUMBER() {
		return CUSTOMER_NUMBER;
	}
	/**
	 * @param cUSTOMER_NUMBER the cUSTOMER_NUMBER to set
	 */
	public void setCUSTOMER_NUMBER(int cUSTOMER_NUMBER) {
		CUSTOMER_NUMBER = cUSTOMER_NUMBER;
	}
	/**
	 * @return the aMOUNT_IN_USD
	 */
	public double getAMOUNT_IN_USD() {
		return AMOUNT_IN_USD;
	}
	/**
	 * @param aMOUNT_IN_USD the aMOUNT_IN_USD to set
	 */
	public void setAMOUNT_IN_USD(double aMOUNT_IN_USD) {
		AMOUNT_IN_USD = aMOUNT_IN_USD;
	}
	/**
	 * @return the uNIQUE_CUST_ID
	 */
	public long getUNIQUE_CUST_ID() {
		return UNIQUE_CUST_ID;
	}
	/**
	 * @param uNIQUE_CUST_ID the uNIQUE_CUST_ID to set
	 */
	public void setUNIQUE_CUST_ID(long uNIQUE_CUST_ID) {
		UNIQUE_CUST_ID = uNIQUE_CUST_ID;
	}
	@Override
	public String toString() {
		return "Invoice [Sl_no=" + Sl_no + ", CUSTOMER_ORDER_ID=" + CUSTOMER_ORDER_ID + ", SALES_ORG=" + SALES_ORG
				+ ", DISTRIBUION_CHANNEL=" + DISTRIBUION_CHANNEL + ", DIVISION=" + DIVISION + ", RELEASED_CREDIT_VALUE="
				+ RELEASED_CREDIT_VALUE + ", PURCHASE_ORDER_TYPE=" + PURCHASE_ORDER_TYPE + ", COMPANY_CODE="
				+ COMPANY_CODE + ", ORDER_CREATION_DATE=" + ORDER_CREATION_DATE + ", ORDER_CREATION_TIME="
				+ ORDER_CREATION_TIME + ", CREDIT_CONTROL_AREA=" + CREDIT_CONTROL_AREA + ", SOLD_TO_PARTY="
				+ SOLD_TO_PARTY + ", ORDER_AMOUNT=" + ORDER_AMOUNT + ", REQUESTED_DELIVERY_DATE="
				+ REQUESTED_DELIVERY_DATE + ", ORDER_CURRENCY=" + ORDER_CURRENCY + ", CREDIT_STATUS=" + CREDIT_STATUS
				+ ", CUSTOMER_NUMBER=" + CUSTOMER_NUMBER + ", AMOUNT_IN_USD=" + AMOUNT_IN_USD + ", UNIQUE_CUST_ID="
				+ UNIQUE_CUST_ID + "]";
	}
    
    
	
	
}