import React from "react";
import { DataGrid } from "@mui/x-data-grid";

function Grid() {
  //creating features
  const columns = [
    { field: "si", headerName: "SI NO", width: 120 },
    { field: "customerOrderId", headerName: "CUSTOMER ORDER ID", width: 240 },
    { field: "salesOrg", headerName: "SALES ORG", width: 160 },
    {
      field: "distributionChannel",
      headerName: "DISTRIBUTION CHANNEL",
      width: 250,
    },
    { field: "companyCode", headerName: "COMPANY CODE", width: 200 },
    {
      field: "orderCreationDate",
      headerName: "ORDER CREATION DATE",
      width: 250,
    },
    { field: "orderamount", headerName: "ORDER AMOUNT", width: 200 },
    { field: "orderCurrency", headerName: "ORDER CURRENCY", width: 220 },
    { field: "customernumber", headerName: "CUSTOMER NUMBER", width: 230 },
  ];

  //Fill the vlaues of the attributes

  const data = [
    {
      id: 1,
      si: 1,
      customerOrderId: 754349803,
      salesOrg: 3911,
      distributionChannel: "United Arab Emirates",
      companyCode: 3290,
      orderCreationDate: "01-01-2022",
      orderamount: 1405.54,
      orderCurrency: "AED",
      customernumber: 1210499770,
    },
    {
      id: 2,
      si: 2,
      customerOrderId: 930253442,
      salesOrg: 2381,
      distributionChannel: "Greece",
      companyCode: 3290,
      orderCreationDate: "01-01-2022",
      orderamount: 1441.4835,
      orderCurrency: "EUR",
      customernumber: 1210351400,
    },
    {
      id: 3,
      si: 3,
      customerOrderId: 819741436,
      salesOrg: 3605,
      distributionChannel: "Argentina",
      companyCode: 3290,
      orderCreationDate: "01-01-2022",
      orderamount: 1065.33,
      orderCurrency: "EUR",
      customernumber: 1210124309,
    },
    {
      id: 4,
      si: 4,
      customerOrderId: 881355361,
      salesOrg: 3645,
      distributionChannel: "Armenia",
      companyCode: 3470,
      orderCreationDate: "02-01-2022",
      orderamount: 302.85,
      orderCurrency: "EUR",
      customernumber: 12311152,
    },
    {
      id: 5,
      si: 5,
      customerOrderId: 821659852,
      salesOrg: 2470,
      distributionChannel: "United States of America",
      companyCode: 3220,
      orderCreationDate: "02-01-2022",
      orderamount: 8380.69,
      orderCurrency: "EUR",
      customernumber: 1230021722,
    },
    {
      id: 6,
      si: 6,
      customerOrderId: 957194828,
      salesOrg: 3150,
      distributionChannel: "United States Minor Outlying Islands",
      companyCode: 3290,
      orderCreationDate: "02-01-2022",
      orderamount: 545.85,
      orderCurrency: "EUR",
      customernumber: 1210183107,
    },
    {
      id: 7,
      si: 7,
      customerOrderId: 806322513,
      salesOrg: 3396,
      distributionChannel: "Serbia",
      companyCode: 3290,
      orderCreationDate: "02-01-2022",
      orderamount: 545.85,
      orderCurrency: "EUR",
      customernumber: 1210499770,
    },
    {
      id: 8,
      si: 8,
      customerOrderId: 922237131,
      salesOrg: 3396,
      distributionChannel: "Turks and Caicos Islands",
      companyCode: 3290,
      orderCreationDate: "02-01-2022",
      orderamount: 562.73,
      orderCurrency: "EUR",
      customernumber: 1210111951,
    },
    {
      id: 9,
      si: 9,
      customerOrderId: 754349803,
      salesOrg: 3911,
      distributionChannel: "United Arab Emirates",
      companyCode: 3290,
      orderCreationDate: "01-01-2022",
      orderamount: 1405.54,
      orderCurrency: "AED",
      customernumber: 1210499770,
    },
    {
      id: 10,
      si: 10,
      customerOrderId: 930253442,
      salesOrg: 2381,
      distributionChannel: "Greece",
      companyCode: 3290,
      orderCreationDate: "01-01-2022",
      orderamount: 1441.4835,
      orderCurrency: "EUR",
      customernumber: 1210351400,
    },
    {
      id: 11,
      si: 11,
      customerOrderId: 819741436,
      salesOrg: 3605,
      distributionChannel: "Argentina",
      companyCode: 3290,
      orderCreationDate: "01-01-2022",
      orderamount: 1065.33,
      orderCurrency: "EUR",
      customernumber: 1210124309,
    },
    {
      id: 12,
      si: 12,
      customerOrderId: 881355361,
      salesOrg: 3645,
      distributionChannel: "Armenia",
      companyCode: 3470,
      orderCreationDate: "02-01-2022",
      orderamount: 302.85,
      orderCurrency: "EUR",
      customernumber: 12311152,
    },
    {
      id: 13,
      si: 13,
      customerOrderId: 821659852,
      salesOrg: 2470,
      distributionChannel: "United States of America",
      companyCode: 3220,
      orderCreationDate: "02-01-2022",
      orderamount: 8380.69,
      orderCurrency: "EUR",
      customernumber: 1230021722,
    },
    {
      id: 14,
      si: 14,
      customerOrderId: 957194828,
      salesOrg: 3150,
      distributionChannel: "United States Minor Outlying Islands",
      companyCode: 3290,
      orderCreationDate: "02-01-2022",
      orderamount: 545.85,
      orderCurrency: "EUR",
      customernumber: 1210183107,
    },
    {
      id: 15,
      si: 15,
      customerOrderId: 806322513,
      salesOrg: 3396,
      distributionChannel: "Serbia",
      companyCode: 3290,
      orderCreationDate: "02-01-2022",
      orderamount: 545.85,
      orderCurrency: "EUR",
      customernumber: 1210499770,
    },
    {
      id: 16,
      si: 16,
      customerOrderId: 922237131,
      salesOrg: 3396,
      distributionChannel: "Turks and Caicos Islands",
      companyCode: 3290,
      orderCreationDate: "02-01-2022",
      orderamount: 562.73,
      orderCurrency: "EUR",
      customernumber: 1210111951,
    },
  ];

  const rows = data.map((row) => ({ ...row, isSelected: false }));

  return (
    <div
      style={{
        height: 500,
        width: "100%",
        backgroundColor: "#595959",
      }}
    >
      <style>
        {`
        .MuiCheckbox-colorPrimary.Mui-checked .MuiSvgIcon-root {
          color: #fc7500; 
        }
        .MuiDataGrid-cell, .MuiDataGrid-row,
        .MuiDataGrid-columnHeader, .MuiCheckbox-root,
        .MuiDataGrid-rowsPerPage, .MuiSelect-root {
          color: #ffffff;
        }
      `}
      </style>
      <DataGrid
        rows={rows}
        columns={columns}
        checkboxSelection
        
        
      />
    </div>
  );
}

export default Grid;