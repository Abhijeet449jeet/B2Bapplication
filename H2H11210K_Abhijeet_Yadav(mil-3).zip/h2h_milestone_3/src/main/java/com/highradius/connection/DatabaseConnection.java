package com.highradius.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	// connection url jdbc:mysql://ipAddress:portnumber/databasename
	static final String URL = "jdbc:mysql://localhost:3306/oap_h2h";
	// Database username
	static final String USER = "root";
	// Database password
	static final String PASS = "Abhijeet@323";

	public Connection connect() throws SQLException {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASS);
			if (con == null) {
				System.out.println("Connection cannot be established");
			}
		} catch (Exception e) {
			throw new RuntimeException("unhandled", e);
		}
		return con;

	}
}