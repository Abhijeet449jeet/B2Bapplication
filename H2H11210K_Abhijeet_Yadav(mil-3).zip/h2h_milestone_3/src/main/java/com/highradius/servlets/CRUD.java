package com.highradius.servlets;
import com.highradius.implementation.*;
import com.highradius.model.*;
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

import com.google.gson.*;
/**
 * Servlet implementation class read
 */

//Instead of using different servlet files I am using switch case to move into
// respective servlets' task which i learned from the reference video in TPMG. 

@WebServlet("/read")
public class CRUD extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * Default constructor. 
     */
	private static InvoiceDao handler;
    public CRUD() {
    	handler = new InvoiceDaoImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action =request.getServletPath();
		switch(action) {
		case "/read":
			read(request,response);
			break;
		case "/insert":
			insert(request,response);
			break;
		case "/update":
			update(request,response);
			break;
		case "/delete":
			delete(request,response);
			break;
		default:
			break;
		}
	}
	
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("reply/html");
		int id=Integer.parseInt(request.getParameter("id"));
		int status=handler.deleteInvoice(id);
			PrintWriter out;
			try {
				out = response.getWriter();
				if(status==1)
				{
					out.println("<h1>Deletion of Invoice Successful.</h1>");
				}
				else {
					out.println("<h1>Deletion of Invoice <b>Failed</b></h1>");

				}
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

	private void update(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException  {
		// TODO Auto-generated method stub
		response.setContentType("reply/html");
		int si = Integer.parseInt(request.getParameter("si"));
	    String customerOrderId = request.getParameter("customerOrderId");
	    String salesOrg = request.getParameter("salesOrg");
	    String distributionChannel = request.getParameter("distributionChannel");
	    String companyCode = request.getParameter("companyCode");
	    String orderCreationDate = request.getParameter("orderCreationDate");
	    String orderCurrency = request.getParameter("orderCurrency");
	    String customerNumber = request.getParameter("customerNumber");
	    double amountInUSD = Double.parseDouble(request.getParameter("amountInUSD"));
	    double orderAmount = Double.parseDouble(request.getParameter("orderAmount"));
	    
	    Invoice e=new Invoice(si, customerOrderId, salesOrg, distributionChannel, companyCode,orderCreationDate, orderCurrency, customerNumber, amountInUSD, orderAmount);
		int status = handler.updateInvoice(si, e);
		PrintWriter out;
		try {
			out = response.getWriter();
			if(status==1)
			{
				out.println("<h1>Updation of Invoice Successful.</h1>");
			}
			else {
				out.println("<h1>Updation of Invoice <b>Failed</b></h1>");

			}
			out.close();
		} catch (IOException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		
		
	}

	private void insert(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException  {
		// TODO Auto-generated method stub
		response.setContentType("reply/html");
		int si = Integer.parseInt(request.getParameter("si"));
	    String customerOrderId = request.getParameter("customerOrderId");
	    String salesOrg = request.getParameter("salesOrg");
	    String distributionChannel = request.getParameter("distributionChannel");
	    String companyCode = request.getParameter("companyCode");
	    String orderCreationDate = request.getParameter("orderCreationDate");
	    String orderCurrency = request.getParameter("orderCurrency");
	    String customerNumber = request.getParameter("customerNumber");
	    double amountInUSD = Double.parseDouble(request.getParameter("amountInUSD"));
	    double orderAmount = Double.parseDouble(request.getParameter("orderAmount"));
	    
	    Invoice e=new Invoice(si, customerOrderId, salesOrg, distributionChannel, companyCode,orderCreationDate, orderCurrency, customerNumber, amountInUSD, orderAmount);
		int status = handler.updateInvoice(si, e);
		PrintWriter out;
		try {
			out = response.getWriter();
			if(status==1)
			{
				out.println("<h1>Insertion of Invoice <b>Successful</b>.</h1>");
			}
			else {
				out.println("<h1>Insertion of Invoice <b>Failed</b></h1>");

			}
			out.close();
		} catch (IOException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}

		
	}

	private void read(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Invoice> data=handler.getInvoice();
		
        // Convert the invoice data to JSON using Gson library
		Gson gson = new Gson();
        String json = gson.toJson(data);
        
     // Set the response content type to JSON
        response.setContentType("application/json");
        
     // Get the response writer
        PrintWriter out;
		try {
			out = response.getWriter();
	        // Write the JSON response
			out.append(json);
	        out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

}
