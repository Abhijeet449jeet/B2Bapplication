package h2h_milestone_1;
import java.util.*;
public class sample {
          public static void main(String args[]) {
          Scanner sc=new Scanner(System.in);
          int num1=sc.nextInt();
          
          
          System.out.println(num1);
          sc.close();
}
}