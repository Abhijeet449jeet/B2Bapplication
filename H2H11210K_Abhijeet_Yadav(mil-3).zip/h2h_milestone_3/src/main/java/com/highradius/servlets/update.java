package com.highradius.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.highradius.implementation.*;
import com.highradius.model.*;

/**
 * Servlet implementation class update
 */
@WebServlet("/updateInvoice")
public class update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static InvoiceDao handler;

    public update() {
    	handler = new InvoiceDaoImpl();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("reply/html");
		int si = Integer.parseInt(request.getParameter("si"));
	    String customerOrderId = request.getParameter("customerOrderId");
	    String salesOrg = request.getParameter("salesOrg");
	    String distributionChannel = request.getParameter("distributionChannel");
	    String companyCode = request.getParameter("companyCode");
	    String orderCreationDate = request.getParameter("orderCreationDate");
	    String orderCurrency = request.getParameter("orderCurrency");
	    String customerNumber = request.getParameter("customerNumber");
	    double amountInUSD = Double.parseDouble(request.getParameter("amountInUSD"));
	    double orderAmount = Double.parseDouble(request.getParameter("orderAmount"));
	    
	    Invoice e=new Invoice(si, customerOrderId, salesOrg, distributionChannel, companyCode,orderCreationDate, orderCurrency, customerNumber, amountInUSD, orderAmount);
		int status = handler.updateInvoice(si, e);
		PrintWriter out;
		try {
			out = response.getWriter();
			if(status==1)
			{
				out.println("<h1>Updation of Invoice Successful.</h1>");
			}
			else {
				out.println("<h1>Updation of Invoice <b>Failed</b></h1>");

			}
			out.close();
		} catch (IOException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}