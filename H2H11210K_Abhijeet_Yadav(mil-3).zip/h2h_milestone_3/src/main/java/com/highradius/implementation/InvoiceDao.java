package com.highradius.implementation;

import com.highradius.model.*;
import java.util.*;

public interface InvoiceDao {
	public ArrayList<Invoice> getInvoice();

	public int insertInvoice(Invoice invoice);

	public int updateInvoice(int id, Invoice invoice);

	public int deleteInvoice(int id);
}
