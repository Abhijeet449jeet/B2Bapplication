package com.highradius.connection;

import java.util.ArrayList;

import com.google.gson.Gson;
import com.highradius.implementation.InvoiceDaoImpl;
import com.highradius.model.Invoice;
import com.highradius.implementation.*;

public class DataFetcher {
	private static InvoiceDao handler;

	public static void main(String[] args) {
		handler = new InvoiceDaoImpl();
//		try (Connection connection = DatabaseConnection.connect()) {
//	         // Create a statement
//	         Statement statement = connection.createStatement();
//
//	         // Execute a query
//	         String query = "SELECT sl_no,customer_Order_Id,sales_Org, distribution_Channel,company_Code,order_Creation_Date, order_Currency,customer_Number,amount_In_USD,order_Amount FROM h2h_oap";
//	         ResultSet resultSet = statement.executeQuery(query);
//
//	         // Process the result set
//	         while (resultSet.next()) {
//	             // Retrieve data from the result set
//	             int si=resultSet.getInt(1);
//	             String customerOrderId=resultSet.getString(2);
//	             String salesOrg=resultSet.getString(3);
//	             String distributionChannel=resultSet.getString(4);
//	             String companyCode=resultSet.getString(5);
//	             String orderCreationDate=resultSet.getString(6);
//	             String orderCurrency=resultSet.getString(7);
//	             String customerNumber=resultSet.getString(8);
//	             double amountInUSD=resultSet.getDouble(9);
//	             double orderAmount=resultSet.getDouble(10);
//	             System.out.print(si + ", ");
//	             System.out.print(customerOrderId + ", ");
//	             System.out.print(salesOrg + ", ");
//	             System.out.print(distributionChannel + ", ");
//	             System.out.print(companyCode + ", ");
//	             System.out.print(orderCreationDate + ", ");
//	             System.out.print(orderCurrency + ", ");
//	             System.out.print(customerNumber + ", ");
//	             System.out.print(amountInUSD + ", ");
//	             System.out.print(orderAmount+"\n");
//
//	             
//	         }
//
//	         // Close the result set and statement
//	         resultSet.close();
//	         statement.close();
//	         connection.close();
//	     } catch (SQLException e) {
//	         e.printStackTrace();
//	     }
		ArrayList<Invoice> data = handler.getInvoice();

		// Convert the invoice data to JSON using Gson library
		Gson gson = new Gson();
		String json = gson.toJson(data);
		System.out.println(json);

	}
}
