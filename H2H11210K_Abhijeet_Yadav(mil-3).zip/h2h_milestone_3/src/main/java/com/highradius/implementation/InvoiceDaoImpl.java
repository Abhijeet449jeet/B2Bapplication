package com.highradius.implementation;

import com.highradius.connection.DatabaseConnection;
import com.highradius.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

import java.util.*;

public class InvoiceDaoImpl implements InvoiceDao {
	DatabaseConnection DatabaseConnection = new DatabaseConnection();

	@Override
	public int insertInvoice(Invoice e) {
		int status = 0;
		try (Connection connection = DatabaseConnection.connect()) {
			// Create a statement
			Statement statement = connection.createStatement();

			// prepared statement
			PreparedStatement ps = connection.prepareStatement(
					"insert into h2h_oap(Sl_no,customer_Order_Id,sales_Org, distribution_Channel,company_Code,order_Creation_Date, order_Currency,customer_Number,amount_In_USD,order_Amount) values(?,?,?,?,?,?,?,?,?,?) ");
			ps.setInt(1, e.getSi());
			ps.setString(2, e.getCustomerOrderId());
			ps.setString(3, e.getSalesOrg());
			ps.setString(4, e.getDistributionChannel());
			ps.setString(5, e.getCompanyCode());
			ps.setString(6, e.getOrderCreationDate());
			ps.setString(7, e.getOrderCurrency());
			ps.setString(8, e.getCustomerNumber());
			ps.setDouble(9, e.getAmountInUSD());
			ps.setDouble(10, e.getOrderAmount());
			status = ps.executeUpdate();

			// Close the result set and statement
			ps.close();
			statement.close();
			connection.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return status;
	}

	@Override
	public ArrayList<Invoice> getInvoice() {
		ArrayList<Invoice> invoice = new ArrayList<Invoice>();
		try (Connection connection = DatabaseConnection.connect()) {
			// Create a statement
			Statement statement = connection.createStatement();

			// Execute a query
			String query = "SELECT sl_no,customer_Order_Id,sales_Org, distribution_Channel,company_Code,order_Creation_Date, order_Currency,customer_Number,amount_In_USD,order_Amount FROM h2h_oap";
			ResultSet resultSet = statement.executeQuery(query);

			// Process the result set
			while (resultSet.next()) {
				// Retrieve data from the result set
				int si = resultSet.getInt(1);
				String customerOrderId = resultSet.getString(2);
				String salesOrg = resultSet.getString(3);
				String distributionChannel = resultSet.getString(4);
				String companyCode = resultSet.getString(5);
				String orderCreationDate = resultSet.getString(6);
				String orderCurrency = resultSet.getString(7);
				String customerNumber = resultSet.getString(8);
				double amountInUSD = resultSet.getDouble(9);
				double orderAmount = resultSet.getDouble(10);
				Invoice temp = new Invoice(si, customerOrderId, salesOrg, distributionChannel, companyCode,
						orderCreationDate, orderCurrency, customerNumber, amountInUSD, orderAmount);
				invoice.add(temp);
			}

			// Close the result set and statement
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return invoice;
	}

	@Override
	public int deleteInvoice(int id) {
		int status = 0;
		try (Connection connection = DatabaseConnection.connect()) {
			// Create a statement
			Statement statement = connection.createStatement();

			// Execute a query
			PreparedStatement ps = connection.prepareStatement("delete from h2h_oap where id=?");
			ps.setInt(1, id);
			status = ps.executeUpdate();

			// Close the result set and statement
			ps.close();
			statement.close();
			connection.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public int updateInvoice(int id, Invoice e) {
		int status = 0;
		try (Connection connection = DatabaseConnection.connect()) {
			// Create a statement
			Statement statement = connection.createStatement();

			// Execute a query
			PreparedStatement ps = connection.prepareStatement(
					"update h2h_oap set sl_no=?,customer_Order_Id=?,sales_Org=?, distribution_Channel=?,company_Code=?,order_Creation_Date=?, order_Currency=?,customer_Number=?,amount_In_USD=?,order_Amount=? where id=?");
			ps.setInt(1, e.getSi());
			ps.setString(2, e.getCustomerOrderId());
			ps.setString(3, e.getSalesOrg());
			ps.setString(4, e.getDistributionChannel());
			ps.setString(5, e.getCompanyCode());
			ps.setString(6, e.getOrderCreationDate());
			ps.setString(7, e.getOrderCurrency());
			ps.setString(8, e.getCustomerNumber());
			ps.setDouble(9, e.getAmountInUSD());
			ps.setDouble(10, e.getOrderAmount());
			ps.setInt(11, id);
			status = ps.executeUpdate();

			// Close the result set and statement
			ps.close();
			statement.close();
			connection.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return status;
		// Instructed to leave blank
	}

}
