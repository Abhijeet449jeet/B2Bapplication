/**
 * 
 */
/**
 * @author KIIT
 *
 */
module h2h_milestone_1 {
	requires java.sql;
}