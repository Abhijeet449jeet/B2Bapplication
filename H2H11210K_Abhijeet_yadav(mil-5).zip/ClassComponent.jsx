import React, { Component } from 'react';

class ClassComponent extends Component {
  render() {
    return (
      <div>
        <br />
      <table style={{ border: '5px solid red' }}>
      <thead>
        <tr>
          <input type="checkbox" />
          <th>Sl. No</th>
          <th>CUSTOMER ORDER ID</th>
          <th>SALES ORG</th>
          <th>DISTRIBUTION CHANNEL</th>
          <th>COMPANY</th>
          <th>ORDER CREATION DATE</th>
          <th>ORDER AMOUNT</th>
          <th>ORDER CURRENCY</th>
          <th>CUSTOMER NUMBER</th>
          </tr>
          <tr>
              <td colSpan="10" style={{ borderTop: '2px solid white' }}></td>
            </tr>
      </thead>
      <tbody>
        <tr>
        <input type="checkbox" />
          <td>1</td>
          <td>754349803</td>
          <td>3911</td>
          <td>United Arab Emirates</td>
          <td>3290</td>
          <td>01-01-2022</td>
          <td>1405.54</td>
          <td>AED</td>
          <td>1210499770</td>
        </tr>
        <tr>
              <td colSpan="10" style={{ borderTop: '2px solid white' }}></td>
            </tr>
        <tr>
        <input type="checkbox" />
          <td>2</td>
          <td>971991639</td>
          <td>2381</td>
          <td>Greece</td>
          <td>3290</td>
          <td>01-01-2022</td>
          <td>1441.4835</td>
          <td>EUR</td>
          <td>1210351400</td>
        </tr>
        <tr>
              <td colSpan="10" style={{ borderTop: '2px solid white' }}></td>
            </tr>
        <tr>
        <input type="checkbox" />
          <td>3</td>
          <td>754349803</td>
          <td>3605</td>
          <td>Argentina</td>
          <td>3290</td>
          <td>01-01-2022</td>
          <td>1065.33</td>
          <td>EUR</td>
          <td>1210124309</td>
        </tr>
        <tr>
              <td colSpan="10" style={{ borderTop: '2px solid white' }}></td>
            </tr>
        <tr>
        <input type="checkbox" />
          <td>4</td>
          <td>930253442</td>
          <td>3605</td>
          <td>Armenia</td>
          <td>3645</td>
          <td>02-01-2022</td>
          <td>302.85</td>
          <td>EUR</td>
          <td>12311152</td>
        </tr>
        <tr>
              <td colSpan="10" style={{ borderTop: '2px solid white' }}></td>
            </tr>
        <tr>
        <input type="checkbox" />
          <td>5</td>
          <td>819741436</td>
          <td>2470</td>
          <td>United States of America</td>
          <td>3220</td>
          <td>01-01-2022</td>
          <td>8380.69</td>
          <td>EUR</td>
          <td>1230021722</td>
        </tr>
        <tr>
              <td colSpan="10" style={{ borderTop: '2px solid white' }}></td>
            </tr>
        <tr>
        <input type="checkbox" />
          <td>6</td>
          <td>881355361</td>
          <td>3150</td>
          <td>United States Minor Outlying Islands</td>
          <td>3290</td>
          <td>02-01-2022</td>
          <td>545.85</td>
          <td>EUR</td>
          <td>1210183107</td>
        </tr>
        <tr>
              <td colSpan="10" style={{ borderTop: '2px solid white' }}></td>
            </tr>
        <tr>
        <input type="checkbox" />
          <td>7</td>
          <td>881355361</td>
          <td>3396</td>
          <td>Serbia</td>
          <td>3290</td>
          <td>02-01-2022</td>
          <td>545.85</td>
          <td>EUR</td>
          <td>1210499770</td>
        </tr>
        <tr>
              <td colSpan="10" style={{ borderTop: '2px solid white' }}></td>
            </tr>
        <tr>
        <input type="checkbox" />
          <td>8</td>
          <td>881355361</td>
          <td>2353</td>
          <td>Turks and Caicos Islands</td>
          <td>3290</td>
          <td>02-01-2022</td>
          <td>562.73</td>
          <td>EUR</td>
          <td>1210111951</td>
        </tr>
      </tbody>
    </table>
    
        </div>
    );
  }
}

export default ClassComponent;
