//import logo from './logo.svg';
import './App.css';
import ClassComponent from './Component/ClassComponent';

function App() {
  return (
    <div className="App">
     <ClassComponent />
    </div>
  );
}

export default App;
