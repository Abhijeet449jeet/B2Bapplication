package com.highradius.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;

import com.highradius.model.Invoice;

public class DatabaseConnection{
	
	static List<Invoice> invoices=new ArrayList<>();
	
	public List<Invoice> getInvoices() {
        return invoices;
    }

    public void addInvoice(Invoice invoice) {
        invoices.add(invoice);
    }
	
    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        ResultSet rs = null;

        String url = "jdbc:mysql://localhost:3306/oap_h2h";
        String username = "root";
        String password = "Abhijeet@323";

        try {
            connection = DriverManager.getConnection(url,username, password);
            statement = connection.createStatement();

            String sqlQuery = "SELECT * FROM h2h_oap";
            rs = statement.executeQuery(sqlQuery);

            while (rs.next()) {
            	invoices.add(new Invoice(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getFloat(6),rs.getString(7),rs.getInt(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getInt(12),rs.getFloat(13),rs.getString(14),rs.getString(15),rs.getString(16),rs.getInt(17),rs.getFloat(18),rs.getLong(19)));
            }
            
            for(Invoice invs: invoices) {
            	System.out.println(invs);
            }
            
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}